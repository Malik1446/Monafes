import os
from dotenv import load_dotenv
import pandas as pd
from sqlalchemy import create_engine, Column, Integer, String, MetaData, Table, ForeignKey
from openpyxl import load_workbook

# Load environment variables
load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL is not set in .env file.")

# Create SQLAlchemy engine and metadata
engine = create_engine(DATABASE_URL)
metadata = MetaData()

# Define tables schema
schools_table = Table(
    "schools", metadata,
    Column("school_id", Integer, primary_key=True, autoincrement=True),
    Column("code", String(4), unique=True, nullable=False),
    Column("name", String, nullable=False),
)

teachers_table = Table(
    "teachers", metadata,
    Column("teacher_id", Integer, primary_key=True, autoincrement=True),
    Column("national_id", String, unique=True, nullable=False),
    Column("internal_code", String, unique=True, nullable=False),
    Column("phone", String, nullable=True),
    Column("email", String, nullable=True),
    Column("school_id", Integer, ForeignKey("schools.school_id"), nullable=False),
)

students_table = Table(
    "students", metadata,
    Column("student_id", Integer, primary_key=True, autoincrement=True),
    Column("national_id", String, unique=True, nullable=False),
    Column("internal_code", String, unique=True, nullable=False),
    Column("school_id", Integer, ForeignKey("schools.school_id"), nullable=False),
)

admins_table = Table(
    "admins", metadata,
    Column("admin_id", Integer, primary_key=True, autoincrement=True),
    Column("name", String, nullable=False),
    Column("national_id", String, unique=True, nullable=False),
    Column("internal_code", String, unique=True, nullable=False),
    Column("username", String, unique=True, nullable=False),
    Column("password", String, nullable=False),
    Column("phone", String, nullable=True),
    Column("email", String, nullable=True),
)

# Create tables if they don't exist
metadata.create_all(engine)

def import_data(excel_path, students_path=None, school_code=None, admins_path=None):
    """
    Import schools, teachers, optional students, and optional admins into the database.
    """
    # Read Excel sheets for schools and teachers
    schools_df = pd.read_excel(excel_path, sheet_name="Schools")
    teachers_df = pd.read_excel(excel_path, sheet_name="Teachers")

    # Prepare and insert schools
    schools_df = schools_df.rename(columns={"رقم المدرسة": "code", "اسم المدرسة": "name"})
    schools_df[["code", "name"]].to_sql("schools", con=engine, if_exists="append", index=False)

    # Build code->school_id mapping
    with engine.connect() as conn:
        result = conn.execute(schools_table.select())
        code_map = {row["code"]: row["school_id"] for row in result}

    # Prepare and insert teachers
    teachers_df = teachers_df.rename(
        columns={
            "رقم الهوية": "national_id",
            "الرقم الداخلي": "internal_code",
            "رمز المدرسة": "code",
            "رقم الجوال": "phone",
            "البريد الإلكتروني": "email"
        }
    )
    teachers_df["school_id"] = teachers_df["code"].map(code_map)
    teacher_cols = ["national_id", "internal_code", "phone", "email", "school_id"]
    teachers_df[teacher_cols].to_sql("teachers", con=engine, if_exists="append", index=False)

    # Optional: import students
    if students_path and school_code:
        students_df = pd.read_excel(students_path, header=None)
        # Detect header
        header_row = next(idx for idx, row in students_df.iterrows() if 'الاسم' in row.values and 'رقم السجل المدني' in row.values)
        students_df = pd.read_excel(students_path, header=header_row)
        students_df = students_df.rename(columns={"الاسم": "name", "رقم السجل المدني": "national_id"})
        students_df = students_df[students_df["national_id"].notnull()]
        students_df["internal_code"] = [f"S{str(i+1).zfill(4)}" for i in range(len(students_df))]
        school_id = code_map.get(school_code)
        if not school_id:
            raise RuntimeError(f"School code {school_code} not found in database")
        students_df["school_id"] = school_id
        students_df[["national_id", "internal_code", "school_id"]].to_sql(
            "students", con=engine, if_exists="append", index=False
        )

    # Optional: import admins
    if admins_path:
        admins_df = pd.read_excel(admins_path, sheet_name="Admins")
        admins_df = admins_df.rename(
            columns={
                "الاسم": "name",
                "رقم الهوية": "national_id",
                "اسم المستخدم": "username",
                "كلمة المرور": "password",
                "رقم الجوال": "phone",
                "البريد الإلكتروني": "email"
            }
        )
        admins_df = admins_df[admins_df["national_id"].notnull()]
        admins_df["internal_code"] = [f"A{str(i+1).zfill(4)}" for i in range(len(admins_df))]
        admin_cols = ["name", "national_id", "internal_code", "username", "password", "phone", "email"]
        admins_df[admin_cols].to_sql("admins", con=engine, if_exists="append", index=False)

    print("Data import completed successfully.")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Import data into the database.")
    parser.add_argument("excel_path", help="Path to the Excel file with Schools and Teachers sheets.")
    parser.add_argument("--students_path", help="Path to the Excel file containing students data.")
    parser.add_argument("--school_code", help="School code for assigning imported students.")
    parser.add_argument("--admins_path", help="Path to the Excel file containing admins data (sheet 'Admins').")
    args = parser.parse_args()
    import_data(args.excel_path, args.students_path, args.school_code, args.admins_path)
