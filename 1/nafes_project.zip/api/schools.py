import os
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker, declarative_base, Session
from pydantic import BaseModel
from typing import List
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL is not set in .env file.")

# Database setup
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# SQLAlchemy model
class School(Base):
    __tablename__ = "schools"
    school_id = Column(Integer, primary_key=True, index=True)
    code = Column(String(4), unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)

# Pydantic schemas
class SchoolBase(BaseModel):
    code: str
    name: str

class SchoolCreate(SchoolBase):
    pass

class SchoolOut(SchoolBase):
    school_id: int

    class Config:
        orm_mode = True

# Router
router = APIRouter(prefix="/schools", tags=["schools"])

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# CRUD Endpoints
@router.post("/", response_model=SchoolOut)
def create_school(school: SchoolCreate, db: Session = Depends(get_db)):
    """Create a new school."""
    existing = db.query(School).filter(School.code == school.code).first()
    if existing:
        raise HTTPException(status_code=400, detail="School code already exists")
    db_school = School(code=school.code, name=school.name)
    db.add(db_school)
    db.commit()
    db.refresh(db_school)
    return db_school

@router.get("/", response_model=List[SchoolOut])
def read_schools(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """Read schools with pagination."""
    return db.query(School).offset(skip).limit(limit).all()

@router.get("/{code}", response_model=SchoolOut)
def read_school(code: str, db: Session = Depends(get_db)):
    """Read a single school by code."""
    db_school = db.query(School).filter(School.code == code).first()
    if not db_school:
        raise HTTPException(status_code=404, detail="School not found")
    return db_school

@router.put("/{code}", response_model=SchoolOut)
def update_school(code: str, school: SchoolCreate, db: Session = Depends(get_db)):
    """Update school details."""
    db_school = db.query(School).filter(School.code == code).first()
    if not db_school:
        raise HTTPException(status_code=404, detail="School not found")
    db_school.name = school.name
    db.commit()
    db.refresh(db_school)
    return db_school

@router.delete("/{code}")
def delete_school(code: str, db: Session = Depends(get_db)):
    """Delete a school."""
    db_school = db.query(School).filter(School.code == code).first()
    if not db_school:
        raise HTTPException(status_code=404, detail="School not found")
    db.delete(db_school)
    db.commit()
    return {"detail": "School deleted"}
