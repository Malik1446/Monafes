import os
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker, declarative_base, Session
from pydantic import BaseModel
from typing import List, Optional
from dotenv import load_dotenv

# Load environment variables
load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL:
    raise RuntimeError("DATABASE_URL is not set in .env file.")

# Database setup
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# SQLAlchemy model
class Admin(Base):
    __tablename__ = "admins"
    admin_id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    national_id = Column(String, unique=True, nullable=False)
    internal_code = Column(String, unique=True, nullable=False)
    username = Column(String, unique=True, nullable=False)
    password = Column(String, nullable=False)
    phone = Column(String, nullable=True)
    email = Column(String, nullable=True)

# Pydantic schemas
class AdminBase(BaseModel):
    name: str
    national_id: str
    phone: Optional[str] = None
    email: Optional[str] = None

class AdminCreate(AdminBase):
    username: str
    password: str

class AdminOut(AdminBase):
    admin_id: int
    internal_code: str
    username: str

    class Config:
        orm_mode = True

class LoginRequest(BaseModel):
    username: str
    password: str

class LoginResponse(BaseModel):
    message: str

# Router
router = APIRouter(prefix="/admins", tags=["admins"])

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# CRUD Endpoints
@router.post("/", response_model=AdminOut, status_code=status.HTTP_201_CREATED)
def create_admin(admin: AdminCreate, db: Session = Depends(get_db)):
    """Create a new admin user."""
    existing = db.query(Admin).filter(Admin.username == admin.username).first()
    if existing:
        raise HTTPException(status_code=400, detail="Username already exists")
    count = db.query(Admin).count() + 1
    internal = f"A{str(count).zfill(4)}"
    db_admin = Admin(
        name=admin.name,
        national_id=admin.national_id,
        internal_code=internal,
        username=admin.username,
        password=admin.password,
        phone=admin.phone,
        email=admin.email
    )
    db.add(db_admin)
    db.commit()
    db.refresh(db_admin)
    return db_admin

@router.get("/", response_model=List[AdminOut])
def read_admins(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """Read admins with pagination."""
    return db.query(Admin).offset(skip).limit(limit).all()

@router.get("/{username}", response_model=AdminOut)
def read_admin(username: str, db: Session = Depends(get_db)):
    """Read a single admin by username."""
    db_admin = db.query(Admin).filter(Admin.username == username).first()
    if not db_admin:
        raise HTTPException(status_code=404, detail="Admin not found")
    return db_admin

@router.put("/{username}", response_model=AdminOut)
def update_admin(username: str, admin: AdminBase, db: Session = Depends(get_db)):
    """Update admin details."""
    db_admin = db.query(Admin).filter(Admin.username == username).first()
    if not db_admin:
        raise HTTPException(status_code=404, detail="Admin not found")
    db_admin.name = admin.name
    db_admin.phone = admin.phone
    db_admin.email = admin.email
    db.commit()
    db.refresh(db_admin)
    return db_admin

@router.delete("/{username}")
def delete_admin(username: str, db: Session = Depends(get_db)):
    """Delete an admin."""
    db_admin = db.query(Admin).filter(Admin.username == username).first()
    if not db_admin:
        raise HTTPException(status_code=404, detail="Admin not found")
    db.delete(db_admin)
    db.commit()
    return {"detail": "Admin deleted"}

@router.post("/login", response_model=LoginResponse)
def login_admin(credentials: LoginRequest, db: Session = Depends(get_db)):
    """Authenticate an admin and return a success message."""
    db_admin = db.query(Admin).filter(
        Admin.username == credentials.username,
        Admin.password == credentials.password
    ).first()
    if not db_admin:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    return {"message": "Login successful"}
