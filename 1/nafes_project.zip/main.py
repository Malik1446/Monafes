import os
from fastapi import FastAPI
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Import routers
from api.schools import router as schools_router
from api.admins import router as admins_router

app = FastAPI(
    title="Nafes Training App API",
    version="1.0",
    description="API for managing schools, admins, teachers, and students in Nafes Training App"
)

# Include routers
app.include_router(schools_router, prefix="/api")
app.include_router(admins_router, prefix="/api")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 8000)),
        reload=True
    )
